let scrollers = document.querySelectorAll(".scroller");
let menuBtn = document.querySelector(".menu-button");
let menu = document.querySelector(".menu");
let menuItems = document.querySelectorAll("a");
let header = document.querySelector(".banner-h1");
let imageText = document.querySelector(".image-container");
let infoText = document.querySelector(".info-wrapper");
let programWrapper = document.querySelector(".program-wrapper");
let programWrapperContent = programWrapper.querySelectorAll("h2");
let apexnumbers = document.querySelector(".apexnumbers");
const cursor = document.querySelector(".mk");
let imageWrapper = document.querySelector(".img-wrapper");
let images = [
  "Default_area_of_study_logo_4.jpg",
  "webp junior/vecteezy_a-young-boy-wearing-a-superhero-costume-stands-in-a_32493963.webp",
  "webp junior/vecteezy_one-young-man-futuristic-blue-illuminated-background_32945071.webp",
  "webp junior/vecteezy_hero-in-his-business-confident-young-businessman-wearing-a_13578990.webp",
];

window.addEventListener("load", () => {
  document.querySelector(".loader").classList.add("loader--hidden");
  document.querySelector(".loader").addEventListener("transitionend", () => {
    document.body.removeChild(document.querySelector(".loader"));
  });
});

programWrapperContent[0].addEventListener("click", () => {
  window.location.href = "accordion.html";
});

programWrapperContent[0].addEventListener("mouseover", () => {
  let image = document.createElement("img");
  image.src = images[0];
  image.style.height = "100%";
  image.style.width = "100%";
  imageWrapper.innerHTML = ""; // Clear previous images
  imageWrapper.appendChild(image);
});

programWrapperContent[1].addEventListener("mouseover", () => {
  let image = document.createElement("img");
  image.src = images[1];
  image.style.height = "100%";
  image.style.width = "100%";
  imageWrapper.innerHTML = ""; // Clear previous images
  imageWrapper.appendChild(image);
});

programWrapperContent[2].addEventListener("mouseover", () => {
  let image = document.createElement("img");
  image.src = images[2];
  image.style.height = "100%";
  image.style.width = "100%";
  imageWrapper.innerHTML = ""; // Clear previous images
  imageWrapper.appendChild(image);
});

programWrapperContent[3].addEventListener("mouseover", () => {
  let image = document.createElement("img");
  image.src = images[3];
  image.style.height = "100%";
  image.style.width = "100%";
  imageWrapper.innerHTML = ""; // Clear previous images
  imageWrapper.appendChild(image);
});

document.addEventListener("mousemove", (e) => {
  let x = e.pageX;
  let y = e.pageY;

  cursor.style.top = y + "px";
  cursor.style.left = x + "px";
});

menuBtn.addEventListener("click", (e) => {
  menuBtn.classList.toggle("active");
  menu.classList.toggle("active");
  menuItems.forEach((item) => {
    item.classList.toggle("active");
  });
});

window.addEventListener("load", () => {
  header.classList.add("active");
});

window.addEventListener("scroll", appear);

function appear(e) {
  let imageOffsetTop = imageText.offsetTop;
  let windowHeight = window.innerHeight;
  let scrollY = window.scrollY || window.pageYOffset;

  // Check if the scroll position is within a certain range from the top of the imageText
  if (scrollY >= imageOffsetTop - windowHeight + 10) {
    imageText.classList.add("active");
  }

  let infoTextOffsetTop = infoText.offsetTop;
  if (scrollY >= infoTextOffsetTop - windowHeight + 10) {
    infoText.classList.add("active");
  }

  let programWrapperOffsetTop = programWrapper.offsetTop;
  let subHeaders = programWrapper.querySelectorAll("h2");
  if (scrollY >= programWrapperOffsetTop - windowHeight + 15) {
    // Loop through all h2 elements inside programWrapper
    subHeaders.forEach((item) => {
      item.classList.add("active"); // Add the 'active' class to each h2 element
    });
  }

  const speed = 500;

  let apexnumbersOffsetTop = apexnumbers.offsetTop;
  let apexStat = apexnumbers.querySelectorAll("h2");
  if (scrollY >= apexnumbersOffsetTop - windowHeight + 150) {
    apexStat.forEach((valueDisplay) => {
      function upData() {
        const target = Number(valueDisplay.getAttribute("data-val"));
        const count = Number(valueDisplay.innerText);
        let inc = Math.max(target / speed, 1);

        if (count < target) {
          valueDisplay.innerText = Math.floor(inc + count);
          setTimeout(upData, 1);
        } else {
          valueDisplay.innerText = target;
        }
      }
      upData();
    });
  } else if (scrollY <= apexnumbersOffsetTop - windowHeight + 100) {
    apexStat.forEach((stat) => {
      stat.innerText = 0;
    });
  }
}

if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  addAnimation();
}

function addAnimation() {
  scrollers.forEach((scroller) => {
    // add data-animated="true" to every `.scroller` on the page
    scroller.setAttribute("data-animated", true);

    // Make an array from the elements within `.scroller-inner`
    const scrollerInner = scroller.querySelector(".scroller__inner");
    const scrollerContent = Array.from(scrollerInner.children);

    // For each item in the array, clone it
    // add aria-hidden to it
    // add it into the `.scroller-inner`
    scrollerContent.forEach((item) => {
      const duplicatedItem = item.cloneNode(true);
      duplicatedItem.setAttribute("aria-hidden", true);
      scrollerInner.appendChild(duplicatedItem);
    });
  });
}
